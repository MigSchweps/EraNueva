                                    jQuery(document).ready(function(){
										
										jQuery.noConflict();
										
										jQuery('#main-nav').tinyNav({
                                        header: true
                                      });
									});